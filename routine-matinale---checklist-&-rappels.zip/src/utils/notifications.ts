import { playMorningChime, triggerHaptic } from './audioVibration';

export type NotificationPermissionStatus = 'granted' | 'denied' | 'default' | 'unsupported';

/**
 * Check current notification support and permission
 */
export function getNotificationPermissionStatus(): NotificationPermissionStatus {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as NotificationPermissionStatus;
}

/**
 * Request notification permission from the user
 */
export async function requestNotificationPermission(): Promise<NotificationPermissionStatus> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission as NotificationPermissionStatus;
  } catch (err) {
    console.warn('Error requesting notification permission:', err);
    // Legacy callback fallback for older Android webviews
    return new Promise((resolve) => {
      try {
        Notification.requestPermission((status) => {
          resolve(status as NotificationPermissionStatus);
        });
      } catch {
        resolve('denied');
      }
    });
  }
}

/**
 * Send an Android-compliant notification.
 * IMPORTANT: Modern Android Chrome requires ServiceWorkerRegistration.showNotification()!
 * Calling new Notification() throws an Illegal Constructor error on Android.
 */
export async function sendPushNotification(
  title: string,
  body: string,
  options?: {
    soundEnabled?: boolean;
    vibrationEnabled?: boolean;
    tag?: string;
  }
): Promise<{ success: boolean; error?: string }> {
  const soundEnabled = options?.soundEnabled ?? true;
  const vibrationEnabled = options?.vibrationEnabled ?? true;
  const tag = options?.tag || 'routine-matinale';

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { success: false, error: 'Notifications non supportées sur ce navigateur.' };
  }

  if (Notification.permission !== 'granted') {
    const perm = await requestNotificationPermission();
    if (perm !== 'granted') {
      return {
        success: false,
        error: 'Permission refusée. Active les notifications dans les paramètres du navigateur ou d\'Android.',
      };
    }
  }

  // Play audio chime and device vibration
  playMorningChime(soundEnabled);
  triggerHaptic('alarm', vibrationEnabled);

  const notifOptions: NotificationOptions & { renotify?: boolean; vibrate?: number[] } = {
    body,
    icon: '/icon.svg',
    badge: '/pwa-192x192.png',
    tag,
    renotify: true,
    requireInteraction: true,
    silent: !soundEnabled, // if silent desired
    // Android haptic pattern: vibrate, pause, vibrate
    vibrate: vibrationEnabled ? [250, 100, 250, 100, 400] : undefined,
    data: {
      url: window.location.href,
      date: new Date().toISOString(),
    },
  };

  try {
    // Standard and REQUIRED method on Android Chrome
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && 'showNotification' in reg) {
        await reg.showNotification(title, notifOptions);
        return { success: true };
      }
    }

    // Fallback for desktop / environments without active service worker
    try {
      new Notification(title, notifOptions);
      return { success: true };
    } catch {
      // If new Notification fails on Android (Illegal constructor), try registering worker
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
          await registration.showNotification(title, notifOptions);
          return { success: true };
        }
      }
      return { success: false, error: 'Impossible d\'afficher la notification sans Service Worker actif.' };
    }
  } catch (err: unknown) {
    const errMsg = err instanceof Error ? err.message : String(err);
    console.error('Failed to trigger notification:', err);
    return { success: false, error: errMsg };
  }
}
