// Web Audio API synthesizer & Android Haptics

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!audioCtx) {
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Play a light, crisp 'pop' when checking/unchecking an item
 */
export function playCheckPop(checked: boolean, soundEnabled = true) {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (checked) {
      // Ascending joyful pop
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    } else {
      // Descending soft pop
      osc.frequency.setValueAtTime(550, now);
      osc.frequency.exponentialRampToValueAtTime(320, now + 0.07);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    }

    osc.start(now);
    osc.stop(now + 0.12);
  } catch (e) {
    console.debug('Audio play skipped:', e);
  }
}

/**
 * Play a friendly morning alarm chime (melodic sequence)
 */
export function playMorningChime(soundEnabled = true) {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.connect(gain);
      gain.connect(ctx.destination);

      const startTime = ctx.currentTime + idx * 0.14;
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.22, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

      osc.start(startTime);
      osc.stop(startTime + 0.38);
    });
  } catch (e) {
    console.debug('Chime failed:', e);
  }
}

/**
 * Play fanfare when all items are checked (100%)
 */
export function playCompletionFanfare(soundEnabled = true) {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [
      { f: 523.25, d: 0.12 }, // C5
      { f: 659.25, d: 0.12 }, // E5
      { f: 783.99, d: 0.12 }, // G5
      { f: 1046.50, d: 0.4 }, // C6
    ];

    let t = ctx.currentTime;
    notes.forEach((note) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.frequency.setValueAtTime(note.f, t);
      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + note.d);

      osc.start(t);
      osc.stop(t + note.d);
      t += note.d * 0.9;
    });
  } catch (e) {
    console.debug('Fanfare skipped:', e);
  }
}

/**
 * Haptic vibrations for Android devices
 */
export function triggerHaptic(type: 'tap' | 'success' | 'alarm' = 'tap', vibrationEnabled = true) {
  if (!vibrationEnabled) return;
  if (typeof window === 'undefined' || !('vibrate' in navigator)) return;

  try {
    if (type === 'tap') {
      navigator.vibrate(25);
    } else if (type === 'success') {
      navigator.vibrate([40, 60, 80]);
    } else if (type === 'alarm') {
      navigator.vibrate([200, 100, 200, 100, 300]);
    }
  } catch (e) {
    console.debug('Vibrate error:', e);
  }
}
