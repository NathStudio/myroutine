/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { PictogramItem, AppSettings } from './types';
import { Header } from './components/Header';
import { ProgressBar } from './components/ProgressBar';
import { PictogramButton } from './components/PictogramButton';
import { SettingsModal } from './components/SettingsModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { playCheckPop, playCompletionFanfare, triggerHaptic } from './utils/audioVibration';
import { sendPushNotification } from './utils/notifications';
import { Sparkles, Plus, Bell, CheckCircle2, ShieldAlert } from 'lucide-react';

const STORAGE_KEY = 'routine_ado_data';

const DEFAULT_DATA: AppSettings = {
  notifTime: '07:10',
  notifEnabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  lastResetDate: new Date().toDateString(),
  notifSentToday: false,
  pictograms: [
    { id: 'p1', icon: '🎒', name: 'Cartable', checked: false },
    { id: 'p2', icon: '🔑', name: 'Clés', checked: false },
    { id: 'p3', icon: '🚌', name: 'Carte de bus', checked: false },
    { id: 'p4', icon: '🥪', name: 'Goûter', checked: false },
    { id: 'p5', icon: '💧', name: 'Gourde', checked: false },
  ],
};

export default function App() {
  const [data, setData] = useState<AppSettings>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          return {
            ...DEFAULT_DATA,
            ...parsed,
            pictograms: parsed.pictograms?.length ? parsed.pictograms : DEFAULT_DATA.pictograms,
          };
        }
      } catch (err) {
        console.error('Error loading saved routine:', err);
      }
    }
    return DEFAULT_DATA;
  });

  const [currentTime, setCurrentTime] = useState<string>('00:00');
  const [currentDate, setCurrentDate] = useState<string>('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [hasPromptedPermission, setHasPromptedPermission] = useState(false);
  const [permissionBannerDismissed, setPermissionBannerDismissed] = useState(false);

  // Keep ref for current data in interval without restarting it
  const dataRef = useRef(data);
  dataRef.current = data;

  // Save to localStorage helper
  const updateData = useCallback((newData: AppSettings | ((prev: AppSettings) => AppSettings)) => {
    setData((prev) => {
      const resolved = typeof newData === 'function' ? newData(prev) : newData;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(resolved));
      } catch (e) {
        console.error('Could not save to localStorage:', e);
      }
      return resolved;
    });
  }, []);

  // Clock & Alarm scheduler loop
  useEffect(() => {
    const updateTimeAndCheckAlarm = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${hh}:${mm}`;
      setCurrentTime(timeStr);

      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
      };
      setCurrentDate(now.toLocaleDateString('fr-FR', options));

      const current = dataRef.current;
      const todayStr = now.toDateString();

      // Check daily reset at midnight
      if (current.lastResetDate !== todayStr) {
        updateData((prev) => ({
          ...prev,
          lastResetDate: todayStr,
          notifSentToday: false,
          pictograms: prev.pictograms.map((p) => ({ ...p, checked: false })),
        }));
        return;
      }

      // Check scheduled notification
      if (
        current.notifEnabled &&
        timeStr === current.notifTime &&
        !current.notifSentToday
      ) {
        // Send Android notification
        updateData((prev) => ({ ...prev, notifSentToday: true }));
        sendPushNotification(
          'Il est temps de vérifier tes affaires ! 🎒',
          'Ouvre l\'application pour valider ta liste de routine matinale.',
          {
            soundEnabled: current.soundEnabled,
            vibrationEnabled: current.vibrationEnabled,
            tag: 'daily-routine-alarm',
          }
        );
      }

      // Safety reset of notif flag at midnight
      if (timeStr !== current.notifTime && now.getHours() === 0 && now.getMinutes() === 0) {
        if (current.notifSentToday) {
          updateData((prev) => ({ ...prev, notifSentToday: false }));
        }
      }
    };

    updateTimeAndCheckAlarm();
    const interval = setInterval(updateTimeAndCheckAlarm, 1000);
    return () => clearInterval(interval);
  }, [updateData]);

  // Handle visibility catch-up (when waking up phone screen)
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        const now = new Date();
        const todayStr = now.toDateString();
        const current = dataRef.current;
        if (current.lastResetDate !== todayStr) {
          updateData((prev) => ({
            ...prev,
            lastResetDate: todayStr,
            notifSentToday: false,
            pictograms: prev.pictograms.map((p) => ({ ...p, checked: false })),
          }));
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [updateData]);

  // Check notification permission on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default' && !hasPromptedPermission) {
        setHasPromptedPermission(true);
      }
    }
  }, [hasPromptedPermission]);

  // Toggle item check
  const handleToggleCheck = (id: string) => {
    const prev = data;
    const target = prev.pictograms.find((p) => p.id === id);
    if (!target) return;

    const nextChecked = !target.checked;
    playCheckPop(nextChecked, prev.soundEnabled);
    triggerHaptic('tap', prev.vibrationEnabled);

    const nextPictograms = prev.pictograms.map((p) =>
      p.id === id ? { ...p, checked: nextChecked } : p
    );

    const allChecked = nextPictograms.length > 0 && nextPictograms.every((p) => p.checked);

    if (allChecked && !target.checked) {
      // Fire celebration!
      playCompletionFanfare(prev.soundEnabled);
      triggerHaptic('success', prev.vibrationEnabled);
      try {
        confetti({
          particleCount: 110,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#22c55e', '#10b981', '#3b82f6', '#eab308', '#ec4899'],
        });
      } catch (e) {
        console.debug('Confetti skip:', e);
      }
    }

    updateData((current) => ({
      ...current,
      pictograms: nextPictograms,
    }));
  };

  // Add new pictogram
  const handleAddPicto = (icon: string, name: string) => {
    const newItem: PictogramItem = {
      id: 'p_' + Date.now(),
      icon: icon || '🎒',
      name: name,
      checked: false,
    };
    updateData((prev) => ({
      ...prev,
      pictograms: [...prev.pictograms, newItem],
    }));
  };

  // Remove pictogram
  const handleRemovePicto = (id: string) => {
    updateData((prev) => ({
      ...prev,
      pictograms: prev.pictograms.filter((p) => p.id !== id),
    }));
  };

  // Manual reset of checkmarks
  const handleManualReset = () => {
    if (window.confirm('Veux-tu décocher tous les objets pour aujourd\'hui ?')) {
      updateData((prev) => ({
        ...prev,
        pictograms: prev.pictograms.map((p) => ({ ...p, checked: false })),
      }));
      triggerHaptic('tap', data.vibrationEnabled);
    }
  };

  // Restore defaults
  const handleResetDefaults = () => {
    if (window.confirm('Restaurer la liste d\'objets par défaut ?')) {
      updateData((prev) => ({
        ...prev,
        pictograms: DEFAULT_DATA.pictograms.map((p) => ({ ...p, checked: false })),
      }));
    }
  };

  // Request notifications from inline banner
  const handleEnableNotifications = async () => {
    if ('Notification' in window) {
      const res = await Notification.requestPermission();
      if (res === 'granted') {
        updateData((prev) => ({ ...prev, notifEnabled: true }));
        sendPushNotification(
          'Notifications activées ! 🔔',
          'Tu recevras tes rappels chaque matin à l\'heure prévue.',
          { soundEnabled: data.soundEnabled, vibrationEnabled: data.vibrationEnabled }
        );
      }
    }
    setPermissionBannerDismissed(true);
  };

  const totalItems = data.pictograms.length;
  const checkedCount = data.pictograms.filter((p) => p.checked).length;
  const isAllComplete = totalItems > 0 && checkedCount === totalItems;
  const showNotifPromptBanner =
    typeof window !== 'undefined' &&
    'Notification' in window &&
    Notification.permission === 'default' &&
    !permissionBannerDismissed;

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto relative bg-gray-950 text-gray-100 shadow-2xl selection:bg-emerald-600 selection:text-white">
      
      {/* HEADER */}
      <Header
        currentTime={currentTime}
        currentDate={currentDate}
        notifTime={data.notifTime}
        notifEnabled={data.notifEnabled}
        notifSentToday={data.notifSentToday}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onManualReset={handleManualReset}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* NOTIFICATION PROMPT BANNER FOR ANDROID */}
      {showNotifPromptBanner && (
        <div className="mx-5 mb-2 p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/90 to-indigo-950/90 border border-blue-600/40 flex items-center justify-between gap-3 shadow-lg animate-in fade-in slide-in-from-top-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 shrink-0">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">Activer les rappels Android ?</p>
              <p className="text-[11px] text-blue-300 truncate">Rappel automatique à {data.notifTime}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleEnableNotifications}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition active:scale-95 shadow-md shadow-blue-900/40"
            >
              Activer
            </button>
            <button
              onClick={() => setPermissionBannerDismissed(true)}
              className="p-1.5 text-gray-400 hover:text-white text-xs rounded-lg"
              title="Plus tard"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* PROGRESS BAR */}
      <ProgressBar total={totalItems} checkedCount={checkedCount} />

      {/* MAIN CHECKLIST VIEW */}
      <main className="flex-1 overflow-y-auto px-5 pb-10 flex flex-col gap-3.5 mt-2">
        {data.pictograms.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-gray-800 rounded-3xl my-6">
            <span className="text-5xl mb-3">🎒</span>
            <h3 className="text-lg font-bold text-white mb-1">Aucun objet dans la liste</h3>
            <p className="text-xs text-gray-400 max-w-xs mb-5">
              Ajoute les affaires indispensables à vérifier chaque matin avant de partir.
            </p>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-2 transition active:scale-95"
            >
              <Plus className="w-4 h-4" /> Configurer les affaires
            </button>
          </div>
        ) : (
          data.pictograms.map((item) => (
            <PictogramButton
              key={item.id}
              item={item}
              onToggle={handleToggleCheck}
            />
          ))
        )}

        {/* Quick Add or Completed State */}
        {isAllComplete && totalItems > 0 && (
          <div className="mt-4 p-5 rounded-3xl bg-gradient-to-b from-emerald-950/70 to-emerald-950/40 border border-emerald-500/30 text-center space-y-2 shadow-xl">
            <div className="inline-flex p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 ring-1 ring-emerald-500/40">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-emerald-200">Mission accomplie !</h3>
            <p className="text-xs text-emerald-300/80 max-w-xs mx-auto">
              Toutes les affaires ont été vérifiées. Tu peux partir l'esprit tranquille.
            </p>
            <div className="pt-2">
              <button
                onClick={handleManualReset}
                className="text-xs font-bold text-emerald-400/90 hover:text-emerald-300 underline"
              >
                Recommencer ou décocher
              </button>
            </div>
          </div>
        )}

        {/* Quick Add shortcut at the bottom */}
        <button
          onClick={() => setIsSettingsOpen(true)}
          className="mt-2 py-3.5 px-4 rounded-2xl border border-dashed border-gray-800 text-gray-400 hover:text-gray-200 hover:border-gray-700 bg-gray-900/30 flex items-center justify-center gap-2 text-xs font-bold transition active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Ajouter ou modifier un objet
        </button>
      </main>

      {/* SETTINGS MODAL */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        notifTime={data.notifTime}
        onNotifTimeChange={(time) => {
          updateData((prev) => ({ ...prev, notifTime: time, notifSentToday: false }));
        }}
        notifEnabled={data.notifEnabled}
        onNotifEnabledChange={(enabled) => {
          updateData((prev) => ({ ...prev, notifEnabled: enabled }));
        }}
        soundEnabled={data.soundEnabled}
        onSoundEnabledChange={(enabled) => {
          updateData((prev) => ({ ...prev, soundEnabled: enabled }));
        }}
        vibrationEnabled={data.vibrationEnabled}
        onVibrationEnabledChange={(enabled) => {
          updateData((prev) => ({ ...prev, vibrationEnabled: enabled }));
        }}
        pictograms={data.pictograms}
        onAddPicto={handleAddPicto}
        onRemovePicto={handleRemovePicto}
        onResetDefaults={handleResetDefaults}
        onResetToday={() => {
          updateData((prev) => ({
            ...prev,
            pictograms: prev.pictograms.map((p) => ({ ...p, checked: false })),
          }));
          setIsSettingsOpen(false);
        }}
        onOpenInstallModal={() => {
          setIsSettingsOpen(false);
          setIsInstallModalOpen(true);
        }}
      />

      {/* ANDROID APK / INSTALL MODAL */}
      <AndroidInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </div>
  );
}
