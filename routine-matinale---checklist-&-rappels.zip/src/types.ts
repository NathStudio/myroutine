export interface PictogramItem {
  id: string;
  icon: string;
  name: string;
  checked: boolean;
  category?: string;
}

export interface AppSettings {
  notifTime: string; // "07:10"
  notifEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  lastResetDate: string;
  notifSentToday: boolean;
  pictograms: PictogramItem[];
}
