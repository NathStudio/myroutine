import React, { useState, useEffect } from 'react';
import {
  X,
  Bell,
  Volume2,
  VolumeX,
  Vibrate,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Timer,
  Smartphone,
  Info,
  RotateCcw,
} from 'lucide-react';
import { PictogramItem } from '../types';
import {
  getNotificationPermissionStatus,
  requestNotificationPermission,
  sendPushNotification,
  NotificationPermissionStatus,
} from '../utils/notifications';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifTime: string;
  onNotifTimeChange: (time: string) => void;
  notifEnabled: boolean;
  onNotifEnabledChange: (enabled: boolean) => void;
  soundEnabled: boolean;
  onSoundEnabledChange: (enabled: boolean) => void;
  vibrationEnabled: boolean;
  onVibrationEnabledChange: (enabled: boolean) => void;
  pictograms: PictogramItem[];
  onAddPicto: (icon: string, name: string) => void;
  onRemovePicto: (id: string) => void;
  onResetDefaults: () => void;
  onResetToday: () => void;
  onOpenInstallModal?: () => void;
}

const PRESET_EMOJIS = [
  { emoji: '🎒', label: 'Cartable' },
  { emoji: '🔑', label: 'Clés' },
  { emoji: '🚌', label: 'Carte de bus' },
  { emoji: '🥪', label: 'Goûter' },
  { emoji: '💧', label: 'Gourde' },
  { emoji: '👟', label: 'Sport' },
  { emoji: '📱', label: 'Téléphone' },
  { emoji: '🔋', label: 'Chargeur' },
  { emoji: '💊', label: 'Médicaments' },
  { emoji: '💻', label: 'Ordinateur' },
  { emoji: '👓', label: 'Lunettes' },
  { emoji: '🧥', label: 'Veste' },
  { emoji: '🎧', label: 'Écouteurs' },
  { emoji: '📚', label: 'Cahiers' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  notifTime,
  onNotifTimeChange,
  notifEnabled,
  onNotifEnabledChange,
  soundEnabled,
  onSoundEnabledChange,
  vibrationEnabled,
  onVibrationEnabledChange,
  pictograms,
  onAddPicto,
  onRemovePicto,
  onResetDefaults,
  onResetToday,
  onOpenInstallModal,
}) => {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermissionStatus>('default');
  const [testResult, setTestResult] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [showAndroidHelp, setShowAndroidHelp] = useState(false);

  // New item inputs
  const [newEmoji, setNewEmoji] = useState('🎒');
  const [newName, setNewName] = useState('');

  useEffect(() => {
    if (isOpen) {
      setPermissionStatus(getNotificationPermissionStatus());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRequestPermission = async () => {
    const status = await requestNotificationPermission();
    setPermissionStatus(status);
    if (status === 'granted') {
      onNotifEnabledChange(true);
      setTestResult('Permission accordée avec succès ! 🎉');
      setTimeout(() => setTestResult(null), 4000);
    } else if (status === 'denied') {
      setShowAndroidHelp(true);
      setTestResult('Notifications refusées. Vérifie les paramètres Android.');
    }
  };

  const handleImmediateTest = async () => {
    setTestResult('Envoi en cours...');
    const res = await sendPushNotification(
      'Alerte Routine Matinale 🎒',
      'Test réussi ! Il est l\'heure de vérifier tes affaires.',
      { soundEnabled, vibrationEnabled, tag: 'routine-test' }
    );
    if (res.success) {
      setTestResult('Notification envoyée avec succès sur Android ! 🔔');
    } else {
      setTestResult(`Erreur: ${res.error || 'Impossible d\'envoyer'}`);
    }
    setTimeout(() => setTestResult(null), 5000);
  };

  const handleDelayedTest = () => {
    setCountdown(5);
    setTestResult('Verrouille ton téléphone ou quitte l\'application pour tester ! ⏱️ (5s)');

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(timer);
          sendPushNotification(
            '⏰ Routine Matinale - Ding Dong !',
            'Ta notification en arrière-plan fonctionne parfaitement sur Android ! 🎒',
            { soundEnabled, vibrationEnabled, tag: 'routine-countdown' }
          );
          setTestResult('Notification différée envoyée ! Regarde ta barre de notifications.');
          setTimeout(() => setTestResult(null), 5000);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSubmitNewPicto = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newName.trim();
    if (!cleanName) return;
    onAddPicto(newEmoji.trim() || '🎒', cleanName);
    setNewName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg max-h-[92vh] flex flex-col bg-gray-950 border border-gray-800 rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-800 bg-gray-900/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-950/80 border border-purple-800/80 text-purple-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Paramètres</h2>
              <p className="text-xs text-gray-400">Notifications &amp; Liste d'affaires</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-gray-800/80 text-gray-400 hover:text-white hover:bg-gray-700 transition"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          
          {/* Section 1: Notifications & Alertes */}
          <section className="bg-gray-900/90 rounded-2xl p-4 sm:p-5 border border-gray-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-blue-400" />
                <h3 className="text-base font-bold text-white">Alerte Programmée</h3>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifEnabled}
                  onChange={(e) => onNotifEnabledChange(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {/* Heure de notification */}
            <div className="flex items-center justify-between bg-gray-950/70 p-3.5 rounded-xl border border-gray-800">
              <div>
                <label htmlFor="notifTimeInput" className="text-sm font-semibold text-gray-200 block">
                  Heure du rappel quotidien
                </label>
                <span className="text-xs text-gray-500">Chaque matin pour vérifier le sac</span>
              </div>
              <input
                id="notifTimeInput"
                type="time"
                value={notifTime}
                onChange={(e) => onNotifTimeChange(e.target.value)}
                className="bg-gray-800 text-white font-mono font-bold text-base px-3 py-2 rounded-xl border border-gray-700 outline-none focus:border-blue-500 transition"
              />
            </div>

            {/* Permission status card */}
            <div className="bg-gray-950/60 p-3 rounded-xl border border-gray-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400 font-medium">Statut permission Android :</span>
                {permissionStatus === 'granted' && (
                  <span className="flex items-center gap-1 font-bold text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Autorisée
                  </span>
                )}
                {permissionStatus === 'denied' && (
                  <span className="flex items-center gap-1 font-bold text-rose-400">
                    <AlertTriangle className="w-3.5 h-3.5" /> Bloquée
                  </span>
                )}
                {permissionStatus === 'default' && (
                  <span className="flex items-center gap-1 font-bold text-amber-400">
                    <Info className="w-3.5 h-3.5" /> À autoriser
                  </span>
                )}
                {permissionStatus === 'unsupported' && (
                  <span className="text-gray-500 font-bold">Non supporté</span>
                )}
              </div>

              {permissionStatus !== 'granted' && permissionStatus !== 'unsupported' && (
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition"
                >
                  <Bell className="w-4 h-4" />
                  Autoriser les notifications sur ce téléphone
                </button>
              )}

              {/* Android Help collapse */}
              {permissionStatus === 'denied' && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAndroidHelp(!showAndroidHelp)}
                    className="text-xs text-blue-400 hover:underline flex items-center gap-1 font-medium"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    Comment autoriser sur Android si bloqué ?
                  </button>

                  {showAndroidHelp && (
                    <div className="mt-2 text-xs bg-gray-900 p-3 rounded-lg border border-gray-800 text-gray-300 space-y-1.5 leading-relaxed">
                      <p className="font-semibold text-white">Sur Google Chrome Android :</p>
                      <ol className="list-decimal list-inside space-y-1 text-gray-400">
                        <li>Appuie sur les réglages du site (icône ⚙️ ou cadenas à gauche de l'adresse web).</li>
                        <li>Touche <strong>Autorisations</strong> puis <strong>Notifications</strong>.</li>
                        <li>Active <strong>Autoriser</strong>.</li>
                        <li>Vérifie également dans les Paramètres Android &gt; Applications &gt; Chrome &gt; Notifications.</li>
                      </ol>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Test buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={handleImmediateTest}
                className="py-2.5 px-3 rounded-xl bg-gray-800 hover:bg-gray-750 text-white font-bold text-xs border border-gray-700 flex items-center justify-center gap-2 transition active:scale-95"
              >
                <Smartphone className="w-4 h-4 text-emerald-400" />
                Tester maintenant
              </button>
              <button
                type="button"
                onClick={handleDelayedTest}
                disabled={countdown !== null}
                className="py-2.5 px-3 rounded-xl bg-gray-800 hover:bg-gray-750 text-white font-bold text-xs border border-gray-700 flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50"
              >
                <Timer className="w-4 h-4 text-blue-400" />
                {countdown ? `Test dans ${countdown}s...` : 'Test dans 5s (Verrouiller)'}
              </button>
            </div>

            {testResult && (
              <div className="p-2.5 rounded-xl bg-gray-950 border border-gray-800 text-center text-xs font-semibold text-emerald-300 animate-in fade-in">
                {testResult}
              </div>
            )}

            {/* Sound & Vibration Toggles */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-800/80">
              <button
                type="button"
                onClick={() => onSoundEnabledChange(!soundEnabled)}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition ${
                  soundEnabled
                    ? 'bg-blue-950/60 border-blue-700/80 text-blue-300'
                    : 'bg-gray-950/60 border-gray-800 text-gray-500'
                }`}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span>Son : {soundEnabled ? 'Activé' : 'Muet'}</span>
              </button>

              <button
                type="button"
                onClick={() => onVibrationEnabledChange(!vibrationEnabled)}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition ${
                  vibrationEnabled
                    ? 'bg-purple-950/60 border-purple-700/80 text-purple-300'
                    : 'bg-gray-950/60 border-gray-800 text-gray-500'
                }`}
              >
                <Vibrate className="w-4 h-4" />
                <span>Vibreur : {vibrationEnabled ? 'Activé' : 'Désactivé'}</span>
              </button>
            </div>
          </section>

          {/* Section 2: Gestion des Pictogrammes */}
          <section className="bg-gray-900/90 rounded-2xl p-4 sm:p-5 border border-gray-800/90 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span className="text-lg">🎒</span> Objets de la Routine ({pictograms.length})
              </h3>
            </div>

            {/* Quick preset chips */}
            <div>
              <span className="text-xs text-gray-400 font-semibold block mb-2">
                Suggestions rapides (clique pour ajouter) :
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                {PRESET_EMOJIS.map((preset) => {
                  const alreadyExists = pictograms.some(
                    (p) => p.name.toLowerCase() === preset.label.toLowerCase()
                  );
                  return (
                    <button
                      key={preset.label}
                      type="button"
                      disabled={alreadyExists}
                      onClick={() => onAddPicto(preset.emoji, preset.label)}
                      className={`text-xs px-2.5 py-1.5 rounded-xl border font-medium flex items-center gap-1 transition ${
                        alreadyExists
                          ? 'opacity-40 border-gray-800 bg-gray-950 text-gray-600 cursor-not-allowed'
                          : 'border-gray-700 bg-gray-800 text-gray-200 hover:bg-gray-750 active:scale-95'
                      }`}
                    >
                      <span>{preset.emoji}</span>
                      <span>{preset.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Formulaire d'ajout personnalisé */}
            <form onSubmit={handleSubmitNewPicto} className="flex gap-2 pt-2">
              <input
                type="text"
                value={newEmoji}
                onChange={(e) => setNewEmoji(e.target.value)}
                placeholder="🎒"
                maxLength={4}
                className="w-14 text-center text-xl bg-gray-950 border border-gray-700 rounded-xl text-white outline-none focus:border-purple-500 py-2.5"
                title="Emoji"
              />
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Nom (ex: Calculatrice)"
                maxLength={40}
                className="flex-1 px-3 py-2.5 bg-gray-950 border border-gray-700 rounded-xl text-white text-sm outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                disabled={!newName.trim()}
                className="px-4 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl font-bold flex items-center justify-center transition active:scale-95"
                title="Ajouter à la liste"
              >
                <Plus className="w-5 h-5" />
              </button>
            </form>

            {/* Existing Items List */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {pictograms.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between p-3 bg-gray-950/80 rounded-xl border border-gray-800 hover:border-gray-700 transition"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-2xl shrink-0">{p.icon}</span>
                    <span className="font-bold text-gray-200 text-sm truncate">{p.name}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemovePicto(p.id)}
                    className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition"
                    title={`Supprimer ${p.name}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-800 text-xs">
              <button
                type="button"
                onClick={onResetToday}
                className="text-gray-400 hover:text-white flex items-center gap-1 font-semibold transition"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Décocher tout aujourd'hui
              </button>
              <button
                type="button"
                onClick={onResetDefaults}
                className="text-gray-500 hover:text-rose-300 transition"
              >
                Restaurer liste par défaut
              </button>
            </div>
          </section>

          {/* Section 3: Android APK & Installation */}
          {onOpenInstallModal && (
            <section className="bg-gradient-to-r from-emerald-950/50 to-gray-900/80 rounded-2xl p-4 border border-emerald-600/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Application Android (APK)</h4>
                  <p className="text-xs text-gray-400">Scanner le QR Code ou installer le WebAPK natif</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenInstallModal();
                }}
                className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 transition active:scale-95 shadow-md shadow-emerald-950/50"
              >
                Ouvrir
              </button>
            </section>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-800 bg-gray-900/60 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-bold text-sm transition"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
