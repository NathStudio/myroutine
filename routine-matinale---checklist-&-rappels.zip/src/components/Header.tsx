import React from 'react';
import { Settings, Bell, Download, RefreshCw, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  currentTime: string;
  currentDate: string;
  notifTime: string;
  notifEnabled: boolean;
  notifSentToday: boolean;
  onOpenSettings: () => void;
  onManualReset: () => void;
  onOpenInstallModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTime,
  currentDate,
  notifTime,
  notifEnabled,
  notifSentToday,
  onOpenSettings,
  onManualReset,
  onOpenInstallModal,
}) => {
  const { isInstallable, install } = usePWAInstall();

  return (
    <header className="px-5 pt-5 pb-3">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-baseline gap-2">
            <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white font-mono">
              {currentTime}
            </h1>
            {notifEnabled && (
              <span
                className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border ${
                  notifSentToday
                    ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80'
                    : 'bg-blue-950/80 text-blue-300 border-blue-800/80'
                }`}
                title={`Alerte programmée à ${notifTime}`}
              >
                <Bell className="w-3 h-3" />
                {notifTime}
              </span>
            )}
          </div>
          <p className="text-sm font-medium text-gray-400 capitalize mt-0.5">
            {currentDate}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* APK / Android Install button */}
          <button
            onClick={() => {
              if (isInstallable) {
                install();
              } else {
                onOpenInstallModal();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/50 transition-all active:scale-95"
            title="Installer l'APK sur Android"
          >
            {isInstallable ? <Download className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            <span>APK Android</span>
          </button>

          {/* Quick daily reset */}
          <button
            onClick={onManualReset}
            className="p-3 rounded-2xl bg-gray-900 border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition active:scale-95"
            title="Réinitialiser les cases d'aujourd'hui"
            aria-label="Réinitialiser"
          >
            <RefreshCw className="w-5 h-5" />
          </button>

          {/* Settings modal toggle */}
          <button
            onClick={onOpenSettings}
            className="p-3 rounded-2xl bg-gray-900 border border-gray-800 text-gray-300 hover:text-white hover:bg-gray-800 transition active:scale-95 relative"
            title="Paramètres de l'alerte et des pictogrammes"
            aria-label="Paramètres"
          >
            <Settings className="w-5 h-5" />
            {!notifEnabled && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-500" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
