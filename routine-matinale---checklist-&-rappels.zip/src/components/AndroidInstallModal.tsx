import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  X,
  Smartphone,
  QrCode,
  Download,
  ExternalLink,
  Copy,
  Check,
  ShieldCheck,
  Package,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, install, isAndroid } = usePWAInstall();
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const appUrl = typeof window !== 'undefined' ? window.location.href.split('?')[0] : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;

  useEffect(() => {
    if (appUrl) {
      QRCode.toDataURL(appUrl, {
        width: 220,
        margin: 1.5,
        color: {
          dark: '#030712',
          light: '#ffffff',
        },
      })
        .then(setQrDataUrl)
        .catch((err) => console.error('QR code generation error:', err));
    }
  }, [appUrl]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md max-h-[92vh] flex flex-col bg-gray-950 border border-gray-800 rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-800 bg-gray-900/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-950 border border-emerald-700/80 text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Installation Android (APK)</h2>
              <p className="text-xs text-gray-400">Installe l'application sur ton smartphone</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 transition"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-sm">
          
          {/* Method 1: WebAPK native install on Android */}
          <section className="p-4 rounded-2xl bg-gradient-to-b from-emerald-950/60 to-gray-900/80 border border-emerald-600/40 space-y-3">
            <div className="flex items-center gap-2 text-emerald-300 font-bold">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Méthode 1 : Installation WebAPK (Directe & Recommandée)</span>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              Sur Android, Google Chrome génère et installe automatiquement un <strong>vrai APK natif (WebAPK)</strong> sans aucun téléchargement risqué de fichier tiers. L'icône apparaît directement dans la liste des applications Android avec les notifications système intégrées.
            </p>

            {isInstallable ? (
              <button
                onClick={install}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 transition active:scale-95 animate-pulse"
              >
                <Download className="w-4 h-4" />
                Installer l'APK maintenant sur cet appareil
              </button>
            ) : (
              <div className="bg-gray-950/70 p-3 rounded-xl border border-gray-800 text-xs text-gray-400 space-y-1.5">
                <p className="font-semibold text-gray-200">Sur ton téléphone Android :</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Ouvre cette page dans Google Chrome sur ton téléphone.</li>
                  <li>Touche le bouton <strong>« Installer App »</strong> ou le menu Chrome <strong>⋮</strong> &gt; <strong>« Installer l'application »</strong>.</li>
                  <li>Android crée et installe l'APK natif en quelques secondes !</li>
                </ol>
              </div>
            )}
          </section>

          {/* QR Code to scan with Android phone */}
          <section className="p-4 rounded-2xl bg-gray-900/80 border border-gray-800 space-y-3">
            <div className="flex items-center gap-2 text-white font-bold">
              <QrCode className="w-5 h-5 text-blue-400" />
              <span>Scanne pour ouvrir sur ton Android</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              {qrDataUrl && (
                <div className="p-2 bg-white rounded-2xl shadow-lg shrink-0">
                  <img src={qrDataUrl} alt="QR Code vers l'application" className="w-32 h-32 rounded-lg" />
                </div>
              )}
              <div className="flex-1 space-y-2 text-center sm:text-left">
                <p className="text-xs text-gray-400 leading-relaxed">
                  Pointe l'appareil photo de ton téléphone vers ce QR Code pour ouvrir l'application directement sur Android et l'installer.
                </p>
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="w-full py-2 px-3 rounded-xl bg-gray-800 hover:bg-gray-750 border border-gray-700 text-gray-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Lien copié !' : 'Copier le lien mobile'}</span>
                </button>
              </div>
            </div>
          </section>

          {/* Method 2: Standalone .APK via PWABuilder (Trusted Web Activity) */}
          <section className="p-4 rounded-2xl bg-gray-900/80 border border-gray-800 space-y-3">
            <div className="flex items-center gap-2 text-white font-bold">
              <Package className="w-5 h-5 text-purple-400" />
              <span>Méthode 2 : Télécharger le package .APK (PWABuilder)</span>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Si tu as besoin du fichier <code>.apk</code> brut ou d'un package Google Play Store (AAB), l'application est prête à 100% pour PWABuilder (outil officiel Microsoft/Google).
            </p>

            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-purple-950/50"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Générer et télécharger le fichier .APK
            </a>
          </section>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-800 bg-gray-900/60 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-bold text-sm transition"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
