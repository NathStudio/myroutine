import React from 'react';
import { Sparkles, CheckCheck } from 'lucide-react';

interface ProgressBarProps {
  total: number;
  checkedCount: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ total, checkedCount }) => {
  const percent = total > 0 ? Math.round((checkedCount / total) * 100) : 0;
  const isComplete = total > 0 && checkedCount === total;

  return (
    <div className="px-5 py-2.5">
      <div className="flex justify-between items-center text-xs font-bold mb-2">
        <div className="flex items-center gap-1.5 text-gray-300">
          <span>Progression du matin</span>
          {isComplete && (
            <span className="inline-flex items-center gap-1 text-[11px] font-extrabold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800">
              <CheckCheck className="w-3 h-3" /> Terminé !
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-400 font-medium">
            {checkedCount}/{total} validés
          </span>
          <span
            className={`font-mono text-sm font-black transition-colors ${
              isComplete ? 'text-emerald-400' : 'text-gray-200'
            }`}
          >
            {percent}%
          </span>
        </div>
      </div>

      <div className="w-full h-3.5 bg-gray-900 border border-gray-800/80 rounded-full overflow-hidden p-0.5 relative shadow-inner">
        <div
          className={`h-full rounded-full transition-all duration-500 ease-out relative ${
            isComplete
              ? 'bg-gradient-to-r from-emerald-500 via-green-400 to-emerald-300 shadow-lg shadow-emerald-500/40'
              : 'bg-gradient-to-r from-emerald-600 to-green-500'
          }`}
          style={{ width: `${percent}%` }}
        >
          {isComplete && (
            <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
          )}
        </div>
      </div>

      {isComplete && (
        <div className="mt-2.5 flex items-center justify-center gap-2 py-1.5 px-3 rounded-xl bg-gradient-to-r from-emerald-950/90 to-green-950/90 border border-emerald-500/30 text-emerald-300 text-xs font-semibold animate-in fade-in zoom-in-95 duration-300">
          <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-spin" style={{ animationDuration: '4s' }} />
          <span>Tout est dans le sac, tu es prêt à décoller !</span>
        </div>
      )}
    </div>
  );
};
