import React from 'react';
import { Check } from 'lucide-react';
import { PictogramItem } from '../types';

interface PictogramButtonProps {
  item: PictogramItem;
  onToggle: (id: string) => void;
}

export const PictogramButton: React.FC<PictogramButtonProps> = ({ item, onToggle }) => {
  return (
    <button
      type="button"
      onClick={() => onToggle(item.id)}
      className={`group relative flex items-center gap-4 p-4 sm:p-5 rounded-3xl border-2 transition-all duration-200 select-none cursor-pointer active:scale-[0.97] ${
        item.checked
          ? 'bg-gradient-to-r from-emerald-950/90 via-emerald-900/70 to-emerald-950/90 border-emerald-500 shadow-xl shadow-emerald-950/60 text-emerald-50 ring-1 ring-emerald-500/30'
          : 'bg-gray-900/90 hover:bg-gray-850/90 border-gray-800/90 hover:border-gray-700 text-gray-300 shadow-md shadow-black/40'
      }`}
      aria-pressed={item.checked}
      aria-label={`${item.name}, ${item.checked ? 'validé' : 'non validé'}`}
    >
      {/* Emoji container with subtle glow */}
      <div
        className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl shrink-0 transition-transform duration-200 group-active:scale-90 ${
          item.checked
            ? 'bg-emerald-500/20 ring-1 ring-emerald-400/40'
            : 'bg-gray-800/80 ring-1 ring-gray-700/50'
        }`}
      >
        <span className="leading-none drop-shadow-sm">{item.icon}</span>
      </div>

      {/* Item title */}
      <div className="flex-1 text-left min-w-0">
        <span
          className={`block text-xl sm:text-2xl font-bold tracking-tight truncate transition-colors ${
            item.checked ? 'text-emerald-100 line-through/0' : 'text-white'
          }`}
        >
          {item.name}
        </span>
        <span className="text-xs font-semibold text-gray-400 block mt-0.5">
          {item.checked ? '✓ Dans les affaires' : 'À vérifier'}
        </span>
      </div>

      {/* Big tactile check indicator */}
      <div
        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full border-2 flex items-center justify-center shrink-0 transition-all duration-200 ${
          item.checked
            ? 'border-transparent bg-emerald-500 shadow-md shadow-emerald-500/40 text-white scale-105'
            : 'border-gray-700 bg-gray-950/50 text-transparent group-hover:border-gray-600'
        }`}
      >
        <Check
          className={`w-5 h-5 sm:w-6 sm:h-6 stroke-[3.5] transition-transform duration-200 ${
            item.checked ? 'scale-100 text-white' : 'scale-0'
          }`}
        />
      </div>
    </button>
  );
};
