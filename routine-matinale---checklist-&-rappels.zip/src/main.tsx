import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker immediately for offline capability and Android push notifications
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('New content available, auto-updating...');
  },
  onOfflineReady() {
    console.log('Routine Matinale is ready for offline use on Android & Desktop');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
